MEET UR CRUSH website
Deploy: upload index.html (drag the unzipped folder) to Netlify Drop (app.netlify.com/drop), Vercel, GitHub Pages or any web host.
Change numbers: open index.html, search "wa.me/" and replace 256763827011 (Eddie) or 256787309012 (Megan).
